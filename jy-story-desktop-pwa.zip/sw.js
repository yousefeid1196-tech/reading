var V='jyd-v1',SHELL=['./','index.html','manifest.json','icon-192.png','icon-512.png'];
self.addEventListener('install',function(e){e.waitUntil(caches.open(V).then(function(c){return c.addAll(SHELL)}).then(function(){return self.skipWaiting()}))});
self.addEventListener('activate',function(e){e.waitUntil(caches.keys().then(function(k){return Promise.all(k.filter(function(x){return x!==V}).map(function(x){return caches.delete(x)}))}).then(function(){return self.clients.claim()}))});
function put(r,res){if(res&&(res.ok||res.type==='opaque')){var c=res.clone();caches.open(V).then(function(ch){ch.put(r,c)})}return res}
self.addEventListener('fetch',function(e){
  var r=e.request;if(r.method!=='GET')return;var u=new URL(r.url);
  if(u.origin===location.origin){
    e.respondWith(fetch(r).then(function(res){return put(r,res)}).catch(function(){return caches.match(r).then(function(h){return h||caches.match('index.html')})}));
  }else if(u.hostname==='cdnjs.cloudflare.com'){
    e.respondWith(caches.match(r).then(function(h){return h||fetch(r).then(function(res){return put(r,res)})}));
  }
});
